
public interface Greet {
	public abstract void Talk();
}
